//
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.
//


#import <Foundation/Foundation.h>

//! Project version number for DynamicsFP.
FOUNDATION_EXPORT double FraudProtectionVersionNumber;

//! Project version string for DynamicsFP.
FOUNDATION_EXPORT const unsigned char FraudProtectionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamicsFP/PublicHeader.h>


